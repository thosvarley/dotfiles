'''
ppd.py

This file was written originally for the ipp-server project and modified
for RCU. Modifications are released under the AGPLv3 (or later).

ipp-server is a pure-Python implementation of a virtual IPP printer.
Copyright (c) 2017, 2018: David Batley (h2g2bob), Alexander (devkral)

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are 
met:

1. Redistributions of source code must retain the above copyright 
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright 
   notice, this list of conditions and the following disclaimer in the 
   documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

...

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-25  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>
'''

from __future__ import division
from __future__ import absolute_import
from __future__ import print_function

import log
import platform

class PPD(object):
    def text(self):
        raise NotImplementedError()


class BasicPostscriptPPD(PPD):
    product = 'RCU'
    manufacturer = 'Davis Remmel'
    model = 'RCU'

    def text(self):
        return b'''*PPD-Adobe: "4.3"
*FormatVersion: "4.3"

*%% This is a minimal config file
*%% and is almost certainly missing lots of features

*%%     ___________
*%%    |           |
*%%    | PPD File. |
*%%    |           |
*%%  (============(@|
*%%  |            | |
*%%  | [        ] | |
*%%  |____________|/
*%%

*%% About this PPD file
*FileVersion: "2.0.1"
*PSVersion: "(2010.000) 250"
*LanguageLevel: "2"
*LanguageEncoding: ISOLatin1
*LanguageVersion: English
*PCFileName: "%(ppdfilename)s"

*%% Basic capabilities of the device
*FileSystem: False

*%% Printer name
*Product: "(%(product)s)"
*Manufacturer:  "%(manufacturer)s"
*ModelName: "%(model)s"
*NickName: "%(model)s"
*ShortNickName: "%(product)s"

*%% Color
*ColorDevice: True
*DefaultColorSpace: CMYK
*Throughput: "1"
*Password: "0"

*%% Page Size
*OpenUI *PageSize: PickOne
*DefaultPageSize: RMPP
*PageSize RM1-RM2: "<</PageSize [445 594]>> setpagedevice"
*PageSize RMPPM: "<</PageSize [260 462]>> setpagedevice"
*PageSize RMPP: "<</PageSize [510 680]>> setpagedevice"
*CloseUI: *PageSize

*DefaultImageableArea: RMPP
*ImageableArea RM1-RM2: "18 18 427 576"
*ImageableArea RMPPM: "18 18 242 444"
*ImageableArea RMPP: "18 18 492 662"

*DefaultPaperDimension: RMPP
*PaperDimension RM1-RM2: "445 594"
*PaperDimension RMPPM: "260 462"
*PaperDimension RMPP: "510 680"

*DefaultPageRegion: RMPP
*PageRegion RM1-RM2: "<</PageSize [445 594]>> setpagedevice"
*PageRegion RMPPM: "<</PageSize [260 462]>> setpagedevice"
*PageRegion RMPP: "<</PageSize [510 680]>> setpagedevice"
''' % \
{
    b"product": self.product.encode("ascii"),
    b"manufacturer": self.manufacturer.encode("ascii"),
    b"model": self.model.encode("ascii"),
    b"ppdfilename": b"%s%s" % (self.model.encode("ascii"), b'.ppd')
}


class BasicPdfPPD(BasicPostscriptPPD):
    model = 'RCU'

    def text(self):
        # The Darwin and Windows cupsFilters don't really matter, since
        # CUPS is bypassed (uses ghostscript instead to process raw
        # postscript input).
        filters = {
            'FreeBSD': None,  # copied from linux,
            'Linux': [
                '*cupsFilter: "application/pdf 0 -"',
                ''],
            'Darwin': [
                '*cupsFilter: "application/pdf application/vnd.cups-pdf 0 pdftopdf"',
                '*cupsFilter: "application/postscript 50 pstopdf"'],
            'Windows': None  # copied from darwin
        }
        filters['FreeBSD'] = filters['Linux']
        filters['Windows'] = filters['Darwin']

        plat = platform.system()
        plat_filters = '\n'.join(filters[plat])
        filtertext = '''
*% The printer can only handle PDF files, so get CUPS to send that
*% https://en.wikipedia.org/wiki/CUPS#Filter_system
*% https://www.cups.org/doc/spec-ppd.html
*cupsVersion: 2.2
*cupsManualCopies: True
*cupsModelNumber: 2
*cupsIPPPrinter: True
''' + plat_filters
        return super(BasicPdfPPD, self).text() + filtertext.encode('utf-8')
