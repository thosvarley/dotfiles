'''
ExportPrefsWidget.py
This is the controller for an ExportPrefsWidget.

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-25  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

import log
from pathlib import Path
import sys

from PySide2.QtWidgets import QWidget, QColorDialog
from PySide2.QtCore import Qt, QFile, QSettings
from PySide2.QtUiTools import QUiLoader
from PySide2.QtGui import QColor

from model.docrender import DocRenderPrefs


class ExportPrefsWidget(QWidget):
    ui_basepath = '.'
    if hasattr(sys, '_MEIPASS'):
        ui_basepath = sys._MEIPASS
    adir = Path(__file__).parent.parent
    bdir = Path(__file__).parent
    ui_filename = Path(adir / bdir / 'ExportPrefsWidget.ui')

    def __init__(self, controller, *args, **kwargs):
        super(type(self), self).__init__(controller.window, *args, **kwargs)
        self.controller = controller

        # load static ui
        ui_file = QFile(Path(
            self.ui_basepath, self.ui_filename).__str__())
        if not ui_file.open(QFile.ReadOnly):
            log.error("Cannot open {}: {}".format(
                ui_file_name, ui_file.errorString()))
            return
        loader = QUiLoader()
        self.window = loader.load(ui_file)
        # self.window.setWindowFlags(Qt.FramelessWindowHint)
        self.window.setWindowFlags(Qt.Tool)
        ui_file.close()

        # load dynamic elements of ui
        # todo! this is duplicated from notebook controller. we should use
        # only one source of etype/function mappings!!! export_items_to_disk()
        EXPORT_TYPES = [
            ('pdf-rm', {
                'title': 'Export PDF (Web UI)',
                'btn_title': 'Export PDF',
                'tooltip': 'Export the selected items as PDF',
                'f': lambda: self.controller.notebook_controller.treewidget.export_items_to_disk(etype='pdf-rm'),
                'eval_valid': 'test_export_pdf_rm'}),
            ('pdf-b', {
                'title': 'Export PDF (Bitmap)',
                'btn_title': 'Export PDF',
                'tooltip': 'Export the selected items as PDF',
                'f': lambda: self.controller.notebook_controller.treewidget.export_items_to_disk(etype='pdf-b'),
                'eval_valid': 'test_export_pdf_bitmap'}),
            ('pdf-v', {
                'title': 'Export PDF (Vector)',
                'btn_title': 'Export PDF',
                'tooltip': 'Export the selected items as PDF',
                'f': lambda: self.controller.notebook_controller.treewidget.export_items_to_disk(etype='pdf-v'),
                'eval_valid': 'test_export_pdf_vector'}),
            ('txt-md', {
                'title': 'Export Typed Text (Markdown)',
                'btn_title': 'Export Markdown',
                'tooltip': 'Export the selected items\' text as Markdown',
                'f': lambda: self.controller.notebook_controller.treewidget.export_items_to_disk(etype='txt-md'),
                'eval_valid': 'test_export_text_markdown'}),
            ('snaphl-txt', {
                'title': 'Export Snap Highlights (Text)',
                'btn_title': 'Export Highlights',
                'tooltip': 'Export the selected items\' snap highlights as text',
                'f': lambda: self.controller.notebook_controller.treewidget.export_items_to_disk(etype='snaphl-txt'),
                'eval_valid': 'test_export_text_highlights'}),
            ('rmdoc-rm', {
                'title': 'Download Archive (Web UI)',
                'btn_title': 'Download',
                'tooltip': 'Download the selected items as RMDOC notebook archives',
                'f': lambda: self.controller.notebook_controller.treewidget.export_items_to_disk(etype='rmdoc-rm'),
                'eval_valid': 'test_export_rmdoc_rm'}),
            ('rmn', {
                'title': 'Download Archive (RMN)',
                'btn_title': 'Download',
                'tooltip': 'Download the selected items as RMN notebook archives',
                'f': lambda: self.controller.notebook_controller.treewidget.export_items_to_disk(etype='rmn'),
                'eval_valid': 'test_download_rmn'})]


        self.qb1 = self.controller.window.quickbtn1_pushButton
        self.qb2 = self.controller.window.quickbtn2_pushButton

        def cb_setbtn(cb):
            cb._button.setText(
                cb.currentData()[1]['btn_title'])
            try:
                cb._button.clicked.disconnect()
            except:
                pass
            cb._button.clicked.connect(
                cb.currentData()[1]['f'])
            if '_hidden' == cb.currentData()[0]:
                cb._button.hide()
            else:
                cb._button.show()
        def cb_onchange(cb):
            # set button element
            cb_setbtn(cb)
            QSettings().setValue(cb._settings_key,
                                 cb.currentData()[0])
            self.eval_buttons()

        cb1 = self.window.quickbtn1_comboBox
        self.cb1 = cb1
        cb2 = self.window.quickbtn2_comboBox
        self.cb2 = cb2
        cb1._button = self.controller.window.quickbtn1_pushButton
        cb2._button = self.controller.window.quickbtn2_pushButton
        cb1._settings_key = 'pane/notebooks/quickbtn1'
        cb2._settings_key = 'pane/notebooks/quickbtn2'

        cb1.currentIndexChanged.connect(lambda: cb_onchange(cb1))
        cb2.currentIndexChanged.connect(lambda: cb_onchange(cb2))

        cb1_findval = QSettings().value(cb1._settings_key)
        cb1_found = 0
        for i, t in enumerate(EXPORT_TYPES):
            cb1.addItem(t[1]['title'],
                       userData=t)
            if t[0] == cb1_findval:
                cb1_found = i
        cb1.setCurrentIndex(cb1_found)

        cb2_findval = QSettings().value(cb2._settings_key)
        cb2_found = -1
        for i, t in enumerate(EXPORT_TYPES):
            cb2.addItem(t[1]['title'],
                       userData=t)
            if t[0] == cb2_findval:
                cb2_found = i
        cb2.addItem('(Hidden)',
                    userData=('_hidden', {
                        'title': 'Hidden',
                        'btn_title': None,
                        'tooltip': None,
                        'f': lambda: (),
                        'eval_valid': None}))
        if cb2_found < 0:
            cb2.setCurrentIndex(cb2.count() - 1)
        else:
            cb2.setCurrentIndex(cb2_found)


        def init_checkbox(widget):
            try:
                state = bool(int(QSettings().value(
                    widget._settings_key)))
                widget.setChecked(state)
            except:
                save_checked_state(widget)
            widget.toggled.connect(
                lambda: save_checked_state(widget))
        def save_checked_state(widget):
            QSettings().setValue(widget._settings_key,
                                 int(widget.isChecked()))

        # Open Immediately
        self.opennow = self.window.opennow_checkBox
        self.opennow._settings_key = 'pane/notebooks/export_pdf_opennow'
        init_checkbox(self.opennow)

        # Web UI Fallback
        self.webui_fb = self.window.webuifb_checkBox
        self.webui_fb._settings_key = 'pane/notebooks/export_pdf_webui_fallback'
        init_checkbox(self.webui_fb)

        # Annotations (highlights)
        self.annotate = self.window.annotate_checkBox
        self.annotate._settings_key = 'pane/notebooks/export_pdf_annotate'
        init_checkbox(self.annotate)

        # Grouped Annotations
        self.grp_annots = self.window.grpannots_checkBox
        self.grp_annots._settings_key = 'pane/notebooks/export_pdf_grouped_annots'
        init_checkbox(self.grp_annots)
        def child_check(master, child):
            child.setEnabled(master.isChecked())
        self.annotate.toggled.connect(lambda: child_check(self.annotate, self.grp_annots))
        child_check(self.annotate, self.grp_annots)

        # Layers
        self.layers = self.window.layers_checkBox
        self.layers._settings_key = 'pane/notebooks/export_pdf_ocg'
        init_checkbox(self.layers)

        # High Density
        self.highdensity = self.window.highdensity_checkBox
        self.highdensity._settings_key = 'pane/notebooks/export_pdf_hires'
        init_checkbox(self.highdensity)

        ##############
        ### COLORS ###
        ################################################################

        def set_color(btn, newc=None):
            if not newc:
                newc = QColorDialog.getColor(
                    btn._color,
                    self.window,
                'Select Color',
                    QColorDialog.ShowAlphaChannel)
                if not newc or not newc.isValid():
                    return
            QSettings().setValue(btn._settings_key, newc)
            init_color(btn)

        def init_color(color_btn):
            label_widget = color_btn._color_label
            c = color_btn._default_color
            try:
                ca = QSettings().value(color_btn._settings_key)
                if ca and type(ca) is QColor:
                    c = ca
                assert False
            except:
                # color not found, using default
                pass
            color_btn._color = c
            css = label_widget.styleSheet()
            css += 'background-color: rgba({}, {}, {}, {});'.format(
                c.red(), c.green(), c.blue(), c.alpha())
            css += 'border-color: rgba({}, {}, {}, {});'.format(
                c.red()/2, c.green()/2, c.blue()/2, c.alpha())
            label_widget.setStyleSheet(css)
            try:
                color_btn.clicked.disconnect()
            except:
                pass
            color_btn.clicked.connect(lambda: set_color(color_btn))
            return

        default_prefs = DocRenderPrefs

        # Black
        self.ink_black = self.window.black_pushButton
        self.ink_black._settings_key = 'pane/notebooks/export_pdf_blackink'
        self.ink_black._color_label = self.window.black_label
        self.ink_black._default_color = default_prefs.black
        init_color(self.ink_black)

        # Gray
        self.ink_gray = self.window.gray_pushButton
        self.ink_gray._settings_key = 'pane/notebooks/export_pdf_grayink'
        self.ink_gray._color_label = self.window.gray_label
        self.ink_gray._default_color = default_prefs.gray
        init_color(self.ink_gray)

        # White
        self.ink_white = self.window.white_pushButton
        self.ink_white._settings_key = 'pane/notebooks/export_pdf_whiteink'
        self.ink_white._color_label = self.window.white_label
        self.ink_white._default_color = default_prefs.white
        init_color(self.ink_white)

        # Blue
        self.ink_blue = self.window.blue_pushButton
        self.ink_blue._settings_key = 'pane/notebooks/export_pdf_blueink'
        self.ink_blue._color_label = self.window.blue_label
        self.ink_blue._default_color = default_prefs.blue
        init_color(self.ink_blue)

        # Red
        self.ink_red = self.window.red_pushButton
        self.ink_red._settings_key = 'pane/notebooks/export_pdf_redink'
        self.ink_red._color_label = self.window.red_label
        self.ink_red._default_color = default_prefs.red
        init_color(self.ink_red)

        # Highlight Yellow
        self.hlt_yellow = self.window.hltyellow_pushButton
        self.hlt_yellow._settings_key = 'pane/notebooks/export_pdf_highlightink'
        self.hlt_yellow._color_label = self.window.hltyellow_label
        self.hlt_yellow._default_color = default_prefs.highlight_yellow
        init_color(self.hlt_yellow)

        # Highlight Green
        self.hlt_green = self.window.hltgreen_pushButton
        self.hlt_green._settings_key = 'pane/notebooks/export_pdf_highlightgreenink'
        self.hlt_green._color_label = self.window.hltgreen_label
        self.hlt_green._default_color = default_prefs.highlight_green
        init_color(self.hlt_green)

        # Highlight Pink
        self.hlt_pink = self.window.hltpink_pushButton
        self.hlt_pink._settings_key = 'pane/notebooks/export_pdf_highlightpinkink'
        self.hlt_pink._color_label = self.window.hltpink_label
        self.hlt_pink._default_color = default_prefs.highlight_pink
        init_color(self.hlt_pink)

        # Highlight Gray
        self.hlt_gray = self.window.hltgray_pushButton
        self.hlt_gray._settings_key = 'pane/notebooks/export_pdf_highlightgrayink'
        self.hlt_gray._color_label = self.window.hltgray_label
        self.hlt_gray._default_color = default_prefs.highlight_gray
        init_color(self.hlt_gray)

        # Reset All
        def reset_colors(color_btns):
            for c in color_btns:
                set_color(c, c._default_color)
        self.reset_colors =self.window.colorreset_pushButton
        self.reset_colors.clicked.connect(lambda: reset_colors([
            self.ink_black, self.ink_gray, self.ink_white, self.ink_blue,
            self.ink_red, self.hlt_yellow, self.hlt_green, self.hlt_pink,
            self.hlt_gray]))

        ##############
        ### WEB UI ###
        #################################################################

        # Annotations (highlights)
        self.webui_hlt = self.window.webui_highlights_checkBox
        self.webui_hlt._settings_key = 'pane/notebooks/export_pdf_webui_highlights'
        init_checkbox(self.webui_hlt)

        # Grouped annotations
        self.webui_grp_hlts = self.window.webui_grphlts_checkBox
        self.webui_grp_hlts._settings_key = 'pane/notebooks/export_pdf_webui_highlights_grouped'
        init_checkbox(self.webui_grp_hlts)

        self.webui_hlt.toggled.connect(
            lambda: child_check(self.webui_hlt, self.webui_grp_hlts))
        child_check(self.webui_hlt, self.webui_grp_hlts)

    def show(self):
        pw = self.controller.window.parent().parent().parent()
        new_pos = pw.frameGeometry().topLeft() \
            + pw.rect().center() - self.window.rect().center()
        self.window.move(new_pos)
        self.window.show()
        self.window.activateWindow()

    def eval_buttons(self):
        # evaluates whether each quick button should be shown based on
        # the notebook tree widget's selection.
        items = self.controller.notebook_controller.get_pruned_selected_items()
        for cb in [self.cb1, self.cb2]:
            satisfied = True
            data = cb.currentData()
            if not data:
                return
            # tooltip
            tt = data[1]['tooltip']
            if tt:
                cb._button.setToolTip(tt)
            # is valid
            efunc = data[1]['eval_valid']
            for item in items:
                ret = False
                if efunc:
                    func = getattr(item, efunc)
                    ret = func()
                if not ret:
                    satisfied = False
                    break
            if not satisfied:
                cb._button.setEnabled(False)
                continue
            cb._button.setEnabled(True)
