'''
file_handler.py
This class manages what happens for various file types.

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-25  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

import log

class FileHandler:
    acceptable_ext = {'textimport': ['.md', '.txt'],
                      'nbarchive': ['.rm', '.rmn', '.rmdoc'],
                      'document': ['.pdf', '.epub']}

    def __init__(self):
        pass

    @classmethod
    def get_acceptable_exts(cls):
        all_exts = set()
        for key in cls.acceptable_ext:
            for ext in cls.acceptable_ext[key]:
                all_exts.add(ext.lower())
                all_exts.add(ext.upper())
                all_exts.add(ext)
        return all_exts
