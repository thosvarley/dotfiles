'''
shader.py
This is the model for a Shader pen (introduced in fw3.15).

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-24  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

from .generic import GenericPen

class ShaderPen(GenericPen):
    color_index = [
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        'highlight_gray',
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
