'''
generic.py
This is the model for a generic QPen (unkown or no specific type).

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-21  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

import log
from PySide2.QtCore import Qt, QLineF
from PySide2.QtGui import QPen

class GenericPen(QPen):
    color_index = [
        'black',
        'gray',
        'white',
        None, # 'highlight_yellow',
        None, # 'highlight_green',
        None, # 'highlight_pink',
        'blue',
        'red',
        None, # 'highlight_gray',
        None, # 'highlight_rmpp' ???
        # new color index values from rmscene/v0.6.0
        None, # green_2
        None, # cyan
        None, # magenta
        None, # yellow_2
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setCapStyle(Qt.RoundCap)
        self.setJoinStyle(Qt.MiterJoin)
        self.setStyle(Qt.SolidLine)

    def set_color_by_index(self, prefs, index):
        # Lookup color in prefs
        if index < 0 or index >= len(self.color_index):
            log.error('set_color_by_index: out of range color index',
                      index)
            index = 0
        assign = self.color_index[index]
        if assign is None:
            log.debug('set_color_by_index: invalid color for pen',
                      index)
            assign = self.color_index[0]
        color = getattr(prefs, assign)
        self.setColor(color)

    def paint_stroke(self, painter, stroke):
        for i, segment in enumerate(stroke.segments):
            if i+1 >= len(stroke.segments):
                # no next segment, last 'to' point
                continue
            
            nextsegment = stroke.segments[i+1]

            # Set the width
            self.setWidthF(segment.width)

            painter.setPen(self)
            painter.drawLine(QLineF(segment.x, segment.y,
                                    nextsegment.x, nextsegment.y))
