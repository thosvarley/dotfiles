'''
io_filetypes.py
This file defines filetypes for importing and exporting.

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-22  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

import log

IMPORT_FILETYPES = {}

EXPORT_FILETYPES = {}

class IOFileType:
    ft_id = ''
    long_title = '' # title
    short_title = '' # btn_title
    tooltip = ''
    f = lambda: ()
    eval_valid = lambda: ()

    def __init__(self):
        pass
