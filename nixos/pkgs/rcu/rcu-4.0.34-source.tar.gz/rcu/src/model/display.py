'''
display.py
This handles the display of each reMarkable model, which is most-useful
when taking screenshots.

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-25  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

...

reStream was used for the RM2 framebuffer capture.
Copyright (c) 2020 Rien Maertens <Rien.Maertens@posteo.be>

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
'''

import log
from PySide2.QtCore import QByteArray, QBuffer, QIODevice
from PySide2.QtGui import QImage, QMatrix
import math
import gc
import ctypes

class DisplayRMGeneric:
    @classmethod
    def from_model(cls, model):
        # Initialize for the model-specific display.
        hwmodel = model.get_hwtype()
        if 'RM1' == hwmodel:
            return DisplayRM1(model)
        elif 'RM2' == hwmodel:
            # Are hacks applied (using rm2fb)? There should be the
            # existence of a new framebuffer.
            if DisplayRM2_rm2fb.applies(model):
                return DisplayRM2_rm2fb(model)
            elif model.is_gt_eq_xochitl_version('3.24'):
                return DisplayRM2_3_24(model)
            elif model.is_gt_eq_xochitl_version('3.6'):
                return DisplayRM2_3_6(model)
            return DisplayRM2(model)
        elif 'RMPP' == hwmodel:
            if model.is_gt_eq_xochitl_version('3.19'):
                return DisplayRMPP_3_19(model)
            return DisplayRMPP(model)
        elif 'RMPPM' == hwmodel:
            return DisplayRMPPM(model)
        log.error('model not recognized: cannot get display for {}'.format(hwmodel))
        return None

    def __init__(self):
        pass


class ProtoDisplayRM:
    screenwidth = 1404
    screenheight = 1872
    realwidth = 1408
    dpi = 226
    bpp = 2
    pixformat = QImage.Format_Grayscale16
    portrait_size = (1404, 1872)
    devicefile = '/dev/fb0'
    print_dimensions = (('157.2', '209.6'), # millimeters
                        ('6.19', '8.25'))   # inches

    @classmethod
    def get_fb_realsize(cls):
        return cls.screenheight * cls.realwidth * cls.bpp
    
    def __init__(self, model):
        # Stores raw image buffer. The exact function that sets this may
        # vary depending upon the rM model.
        self.model = model

        # Cache of raw framebuffer data. Speeds up soft-refresh
        # operations like getting a rotated copy.
        self.raw_pixel_data = None
        self.capture_fb_cmd = None

    def invalidate_pixel_cache(self, clear_addr=False):
        self.raw_pixel_data = None
        gc.collect()
        if clear_addr:
            log.info('clearing cached framebuffer memory address')
            self.capture_fb_cmd = None

    def get_png_data(self, rotation=0):
        return

########################################################################
## RM1 #################################################################

class DisplayRM1(ProtoDisplayRM):
    def _grab_fb(self):
        out, err = self.model.run_cmd(
            'dd if={} bs=5271552 count=1'.format(type(self).devicefile),
            raw=True)
        if len(out) == 0:
            log.error('framebuffer length was 0; aborting')
            return
        self.raw_pixel_data = out
        return self.raw_pixel_data

    def get_png_data(self, rotation=0):
        pixformat = self.pixformat
        realwidth = self.realwidth
        width = self.screenwidth
        height = self.screenheight

        # Use cached data whenever possible (refreshing takes seconds).
        if self.raw_pixel_data:
            raw_fb = self.raw_pixel_data
        else:
            raw_fb = self._grab_fb()

        # The copy() operation crops off the black border. Convert to
        # Gray8 to reduce saved file size.
        qimage = QImage(raw_fb, realwidth, height, pixformat).copy(
            0, 0, width, height).convertToFormat(
                QImage.Format_Grayscale8)

        center = qimage.rect().center()
        matrix = QMatrix()
        if rotation:
            matrix.translate(center.x(), center.y())
            matrix.rotate(rotation)
            if rotation in (90, 270):
                width, height = (height, width)
        qimage_rot = qimage.transformed(matrix)

        # Dump as PNG
        ba = QByteArray()
        buffer = QBuffer(ba)
        buffer.open(QIODevice.WriteOnly)
        qimage_rot.save(buffer, 'PNG')
        pngdata = ba.data()

        ctypes.c_long.from_address(id(qimage)).value=1
        ctypes.c_long.from_address(id(qimage_rot)).value=1
        del qimage
        del qimage_rot
        gc.collect()
        
        return (pngdata, (width, height))


class DisplayRM2_rm2fb(DisplayRM1):
    devicefile = '/dev/shm/swtfb.01'
    realwidth = 1404

    @classmethod
    def applies(cls, model):
        cmd = 'test -e {}; echo $?'.format(cls.devicefile)
        out, err = model.run_cmd(cmd)
        if len(err):
            log.error('problem testing for rm2fb')
            log.error(err)
            return
        out = out.strip('\n')
        if '0' == out:
            log.info('detected rm2fb')
            return True
        return False

########################################################################
## RM2 #################################################################

class DisplayRM2(ProtoDisplayRM):
    screenwidth = 1872
    screenheight = 1404
    realwidth = 1872
    bpp = 1
    pixformat = QImage.Format_Grayscale8
    pagesize = 4096
    fb_offset = 0
    skip_bytes = 0
    rawfb_rotation = -90

    def __init__(self, model):
        ProtoDisplayRM.__init__(self, model)

    def _cache_memory_locations(self):
        log.info('caching display memory locations')
        self.fb_size = self.get_fb_realsize()

        out, err = self.model.run_cmd('pidof xochitl')
        if len(err):
            log.error('problem getting pid of xochitl')
            log.error(e)
            return
        pid = out.strip()

        # In-memory framebuffer location is just after the noise from
        # /dev/fb0.
        cmd = "grep -C1 '{}' /proc/{}/maps | tail -n1 | sed 's/-.*$//'".format(type(self).devicefile, pid)
        # log.debug('cache memory command:', cmd)
        out, err = self.model.run_cmd(cmd)
        if len(err):
            log.error('problem getting address of RM2 framebuffer')
            log.error(err)
            return
        # log.debug('++ memory address', out.strip())
        skip_bytes = self.skip_bytes + int(out.strip(), 16) + 8
        block_size = type(self).pagesize
        fb_start = int(skip_bytes / block_size)
        self.fb_offset = skip_bytes % block_size
        fb_length = math.ceil(self.fb_size / block_size)
        self.capture_fb_cmd = '''dd if=/proc/{}/mem bs={} \
                                 skip={} count={} 2>/dev/null'''.format(
                                     pid, block_size,
                                     fb_start, fb_length)
        # log.debug('capture_fb_cmd', self.capture_fb_cmd)

    def _grab_fb(self):
        if not self.capture_fb_cmd:
            self._cache_memory_locations()
        out, err = self.model.run_cmd(self.capture_fb_cmd, raw=True)
        if len(err):
            log.error('problem grabbing framebuffer')
            log.error(str(err))
            return
            
        # Because the grab captured excess data (it was aligned to the
        # page size) we need to trim some off.
        raw_fb_4bit = out[self.fb_offset:][:self.fb_size]

        # RM2 only uses the 4 least significant bits (16 shades of gray)
        raw_fb_8bit = bytearray()
        for i, b in enumerate(raw_fb_4bit):
            raw_fb_8bit.append((b & 0b00001111) * 17)

        self.raw_pixel_data = raw_fb_8bit
        return self.raw_pixel_data

    def get_png_data(self, rotation=0):
        width = type(self).realwidth
        height = type(self).screenheight
        pixformat = type(self).pixformat
        
        # Use cached data whenever possible (refreshing takes seconds).
        if self.raw_pixel_data:
            raw_fb = self.raw_pixel_data
        else:
            raw_fb = self._grab_fb()

        qimage = QImage(raw_fb, width, height, pixformat)

        # Compensate for RM2 portrait being -90deg.
        rotation += self.rawfb_rotation
        center = qimage.rect().center()
        matrix = QMatrix()
        if rotation:
            matrix.translate(center.x(), center.y())
            matrix.rotate(rotation)
        rotated_qi = qimage.transformed(matrix)

        if 0 != rotation % 180:
            width, height = (height, width)

        # Dump as PNG
        ba = QByteArray()
        buffer = QBuffer(ba)
        buffer.open(QIODevice.WriteOnly)
        rotated_qi.save(buffer, 'PNG')
        pngdata = ba.data()

        ctypes.c_long.from_address(id(qimage)).value=1
        ctypes.c_long.from_address(id(rotated_qi)).value=1
        del qimage
        del rotated_qi
        gc.collect()
        
        return (pngdata, (width, height))


class DisplayRM2_3_6(DisplayRM2):
    # For whatever reason, the framebuffer format changed in fw.3.6.
    # Every other byte holds data (and others are 0x00). Bytes like
    # 0xFF are represented as 0b00011110, and need to be shifted
    # right. The image also needs a flip and transpose.
    bpp = 2

    def _grab_fb(self):
        if not self.capture_fb_cmd:
            self._cache_memory_locations()
        out, err = self.model.run_cmd(self.capture_fb_cmd, raw=True)
        if len(err):
            log.error('problem grabbing framebuffer')
            log.error(str(err))

        # Because the grab captured excess data (it was aligned to the
        # page size) we need to trim some off.
        raw_fb_4bit = out[self.fb_offset:][:self.fb_size]

        # Read every other byte, ignoring 0x00 in between
        outbin = bytearray()
        length = len(raw_fb_4bit)
        b = 0
        while b < length:
            r1 = raw_fb_4bit[b]
            r1 = (r1 >> 1) * 17  # Convert to 8bit gray
            outbin.append(r1)
            b += 2
        # Reverse to match fw.3.5 framebuffer format
        outbin.reverse()
        del raw_fb_4bit

        # Flip image to match fw.3.5 framebuffer format
        outbin2 = bytearray()
        width = type(self).realwidth
        l = 0
        while l < len(outbin):
            start = l
            end = l + width
            sect = outbin[start:end]
            sect.reverse()
            outbin2 += sect
            l += width
        del outbin
        raw_fb_8bit = outbin2
        del outbin2

        self.raw_pixel_data = raw_fb_8bit
        return self.raw_pixel_data

class DisplayRM2_3_24(DisplayRM2):
    # Beginning with 3.23, RCU started having an issue where 1 out of 10
    # Xochitl restarts caused the framebuffer capture to fail. It was
    # not known what the issue was until 3.24, when rM went all-in and
    # broke RM2+3.24 screenshots totally. The actual issue was that rM
    # started holding color information, and the screenbuffer switched
    # to ABGR32 (called Format_ARGB32 ineptly by Qt).
    screenwidth = 1404
    screenheight = 1872
    realwidth = 1404
    bpp = 4
    pixformat = QImage.Format_ARGB32
    pagesize = 4096
    skip_bytes = 2629632  ## todo: maybe do a search instead. gimp
                          ## showed it needs an offset of 2629640 but
                          ## that could change in future firmware. rm2
                          ## class does a +8 to this, therefore I did
                          ## a -8 here (from 2629640 to 2629632).
    rawfb_rotation = 0

    def _grab_fb(self):
        if not self.capture_fb_cmd:
            self._cache_memory_locations()
        out, err = self.model.run_cmd(self.capture_fb_cmd, raw=True)
        if len(err):
            log.error('problem grabbing framebuffer')
            log.error(str(err))
        self.raw_pixel_data = out[self.fb_offset:][:self.fb_size]
        return self.raw_pixel_data

########################################################################
## RMPP ################################################################

class DisplayRMPP(ProtoDisplayRM):
    screenwidth = 1624
    screenheight = 2160
    realwidth = 1620
    dpi = 228.6
    bpp = 4
    pixformat = QImage.Format_ARGB32  # Just a placeholder format
    portrait_size = (1620, 2160)
    devicefile = None
    print_dimensions = (('180', '240'),    # millimeters
                        ('7.08', '9.44'))  # inches

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def invalidate_pixel_cache(self, clear_addr=False):
        self.raw_pixel_data = None
        gc.collect()
        if clear_addr:
            log.info('clearing cached framebuffer memory address')
            self.capture_fb_cmd = None

    def _cache_memory_locations(self):
        log.info('caching display memory locations')

        out, err = self.model.run_cmd('pidof xochitl')
        if len(err):
            log.error('problem getting pid of xochitl')
            log.error(e)
            return
        pid = out.strip()

        ################################################################
        # Ref: https://github.com/owulveryck/goMarkableStream/issues/117
        ################################################################

        # Find potential memory pages. It used to be that we just took
        # the last one available. Somewhere in the fw3.13 to 3.18ish
        # range, this can appear one page earlier.
        cmd = '''cat /proc/{}/maps \
                     | grep -A1 /dev/dri/card0 \
                     | grep 'rw-p' \
                     | cut -d' ' -f1'''.format(pid)
        out, err = self.model.run_cmd(cmd)
        pages = out.strip().splitlines()

        # Pick the first one big enough to hold the framebuffer data
        memlo = 0
        memhi = 0
        dumplen = 0
        for r in pages:
            sp = r.split('-')
            memlo = int(sp[0], 16)
            memhi = int(sp[1], 16)
            dumplen = memhi - memlo
            if self.get_fb_realsize() <= dumplen:
                # found it
                break

        # dump the mem range
        self.capture_fb_cmd = 'dd if=/proc/{}/mem \
                                  skip={} \
                                  count={} \
                                  bs=1024 \
                                  iflag=skip_bytes,count_bytes \
                                  2>/dev/null'.format(
                                      pid,
                                      memlo,
                                      dumplen)

    # def _grab_fb_inlineread(self):
    def _grab_fb(self):
        log.info('grabbing new framebuffer')
        if not self.capture_fb_cmd:
            self._cache_memory_locations()
        # log.debug('getting raw framebuffer...')
        raw_fb_32bit = bytearray()
        bytes_read = 0
        out, err = self.model.run_cmd(self.capture_fb_cmd,
                                      raw_noread=True)
        while True:
            # log.debug('START')
            # log.debug('offset is', bytes_read)
            # always skip the first 8 bytes
            try:
                # go to header start
                out.read(8)
            except:
                # couldn't read -- no more file
                # just for safety
                break
            bytes_read += 8
            # read header
            header = out.read(8)
            bytes_read += 8
            # parse payload length
            length = int.from_bytes(header, 'little')
            # log.debug('length is', length)
            # check for match to expected payload size
            if length < (self.screenwidth \
                         * self.screenheight \
                         * self.bpp):
                # Not our target, skip the data
                # log.debug('not the target -- skipping')
                payll = length - 16 - 2
                if payll < 0:
                    log.error('problem with display payll: less than 0! breaking...')
                    break
                out.read(payll)
                # log.debug('read out', payll)
                bytes_read += payll
            else:
                # log.debug('found target payload at', bytes_read)
                break

        # Read each row, skip the last 4 pixels
        for y in range(0, self.screenheight):
            # raw_fb_32bit += out.read(self.realwidth * self.bpp) # bytes
            row = out.read(self.realwidth * self.bpp)
            # this is slow...
            for i in row:
                raw_fb_32bit.append(i)
            # skip last 4 of row
            out.read(4 * self.bpp)

        out.close()
        # log.debug('put it all in bytes')
        # log.debug('bytes length is', len(raw_fb_32bit))
        self.raw_pixel_data = raw_fb_32bit
        return self.raw_pixel_data

    def get_png_data(self, rotation=0):
        width = self.realwidth
        height = self.screenheight
        # Use cached data whenever possible
        raw_fb = self.raw_pixel_data
        if not raw_fb:
            raw_fb = self._grab_fb()
        # this prevents a crash (non-valid data passed to qimage) but
        # isn't a finished solution. TODO !!
        if not raw_fb or len(raw_fb) != (width * height * self.bpp):
            # if still nada, we have to break. qt segfaults
            log.error('raw_fb did not pass sanity check')
            return None

        # Crop to portrait size (various firmware verisons mess with
        # real line length in px).
        qimage = QImage(raw_fb,
                        width,
                        height,
                        self.pixformat).copy(
                            0, 0,
                            self.portrait_size[0], self.portrait_size[1])
        # Process rotation
        center = qimage.rect().center()
        matrix = QMatrix()
        if rotation:
            matrix.translate(center.x(), center.y())
            matrix.rotate(rotation)
        rotated_qi = qimage.transformed(matrix)
        if 0 != rotation % 180:
            width, height = (height, width)
        # Dump as PNG
        ba = QByteArray()
        buffer = QBuffer(ba)
        buffer.open(QIODevice.WriteOnly)
        rotated_qi.save(buffer, 'PNG')
        pngdata = ba.data()
        ctypes.c_long.from_address(id(qimage)).value = 1
        ctypes.c_long.from_address(id(rotated_qi)).value = 1
        del qimage
        del rotated_qi
        gc.collect()
        return (pngdata, (width, height))

class DisplayRMPP_3_19(DisplayRMPP):
    screenwidth = 1628
    realwidth = 1628
    portrait_size = (1620, 2160)

class DisplayRMPPM(DisplayRMPP):
    screenwidth = 954
    screenheight = 1696
    realwidth = 956
    portrait_size = (screenwidth, screenheight)
    dpi = 264
    print_dimensions = (('92', '163'),     # millimeters
                        ('3.61', '6.42'))  # inches
