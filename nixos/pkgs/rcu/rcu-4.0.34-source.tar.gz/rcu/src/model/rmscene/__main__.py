'Experimental cli helpers.\n\nCopyright (c) 2023 Rick Lupton\n\nPermission is hereby granted, free of charge, to any person obtaining a copy\nof this software and associated documentation files (the "Software"), to deal\nin the Software without restriction, including without limitation the rights\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\ncopies of the Software, and to permit persons to whom the Software is\nfurnished to do so, subject to the following conditions:\n\nThe above copyright notice and this permission notice shall be included in all\ncopies or substantial portions of the Software.\n\nTHE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\nSOFTWARE.'
import sys
import argparse
from . import read_blocks

def parse_args(args):
    parser = argparse.ArgumentParser(prog='rmscene')
    parser.add_argument('file', type=argparse.FileType('rb'), help='filename to read')
    return parser.parse_args(args)

def pprint_file(args)  :
    import pprint
    result = read_blocks(args.file)
    for el in result:
        print()
        pprint.pprint(el)
if __name__ == '__main__':
    args = parse_args(sys.argv[1:])
    pprint_file(args)
