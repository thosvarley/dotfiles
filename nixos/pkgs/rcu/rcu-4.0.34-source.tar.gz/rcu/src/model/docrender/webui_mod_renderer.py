'''
webui_mod_renderer.py
Rendering logic for post-processing Web UI--exported PDFs.

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-25  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

import log
import pikepdf

from PySide2.QtCore import QSettings, QRectF

class WebUIModRenderer:
    def __init__(self, model):
        self.author = model.device_info['rcuname']
        self.embed_highlights = bool(int(QSettings().value('pane/notebooks/export_pdf_webui_highlights') or 0))
        self.group_highlights = bool(int(QSettings().value('pane/notebooks/export_pdf_webui_highlights_grouped') or 0))

    def go(self, filepath):
        if not self.embed_highlights:
            return
        my_pdf = pikepdf.Pdf.open(filepath, allow_overwriting_input=True)
        for pi, page in enumerate(my_pdf.pages):
            try:
                for stream_index, stream in enumerate(page.Contents):
                    try:
                        stream_bytes = stream.read_bytes()
                    except:
                        # log.debug('[data] NONE!! ci bytes cannot be read')
                        continue
                    # The following string appears to be in all reMarkable-
                    # inserted ink content streams. It's very possible
                    # that other software might produce something similar,
                    # but this is hacked after all...
                    if b'0 0 0 RG 0 0 0 rg 1 w 0 J 0 j\n/FXE1 gs q' not in stream_bytes:
                        continue
                    p = pikepdf.parse_content_stream(stream)
                    color = None
                    extracted_rects = []
                    delete_indexes = []
                    for ti, t in enumerate(p):
                        # color
                        if pikepdf.Operator('rg') == t[-1]:
                            color = [float(t[0][0]),
                                     float(t[0][1]),
                                     float(t[0][2])]
                            continue
                        # rect
                        elif pikepdf.Operator('m') == t[-1]:
                            # This is a pretty crappy way of doing it.
                            # reMarkable can write multiple successive
                            # highlights without calling /f (fill)
                            # sample data:
                            # q
                            # 1 0 0 -1 0 679.67999 cm
                            # 0 0 0 RG 0 0 0 rg 1 w 0 J 0 j
                            # /FXE1 gs q 1 .92941177 .45882353 rg 0 0 0 RG /FXE2 gs 0 0 m 100.119469 605.71075 m 230.74744 605.71075 l 230.74744 592.96075 l 100.119469 592.96075 l f Q
                            # q .74509805 .91764706 .99607843 rg 0 0 0 RG /FXE2 gs 0 0 m 99.592476 578.80829 m 383.37341 578.80829 l 383.37341 566.05829 l 99.592476 566.05829 l f Q
                            # q .94901961 .61960787 1 rg 0 0 0 RG /FXE2 gs 0 0 m 99.940971 551.90576 m 449.67325 551.90576 l 449.67325 539.15576 l 99.940971 539.15576 l f Q
                            # q 1 .7647059 .54901963 rg 0 0 0 RG /FXE2 gs 0 0 m 100.119469 435.32889 m 402.19238 435.32889 l 402.19238 422.57886 l 100.119469 422.57886 l f Q
                            # q .67450982 1 .52156866 rg 0 0 0 RG /FXE2 gs 0 0 m 100.280975 417.3941 m 249.19243 417.3941 l 249.19243 404.6441 l 100.280975 404.6441 l f Q
                            # q .78039217 .78039217 .7764706 rg 0 0 0 RG /FXE2 gs 0 0 m 100.365974 264.94647 m 433.32782 264.94647 l 433.32782 252.19649 l 100.365974 252.19649 l f Q
                            # q .78039217 .78039217 .7764706 rg 0 0 0 RG /FXE2 gs 0 0 m 141.56546 349.98959 m 168.68893 349.98959 l 168.68893 342.79858 l 141.56546 342.79858 l 100.744225 341.63812 m 204.51221 341.63812 l 204.51221 333.70764 l 100.744225 333.70764 l 100.784592 332.46863 m 173.87183 332.46863 l 173.87183 324.78036 l 100.784592 324.78036 l 100.744225 323.70279 m 204.51221 323.70279 l 204.51221 315.77231 l 100.744225 315.77231 l 100.946098 314.10828 m 126.399338 314.10828 l 126.399338 306.93005 l 100.946098 306.93005 l f Q
                            # Q

                            # Skip ahead for anything that doesn't
                            # resemble a rect
                            if pikepdf.Operator('l') != p[ti + 1][-1] \
                               or pikepdf.Operator('l') != p[ti + 2][-1] \
                                   or pikepdf.Operator('l') != p[ti + 3][-1] \
                                       or (pikepdf.Operator('m') != p[ti + 4][-1] \
                                           and pikepdf.Operator('f') != p[ti + 4][-1]):
                                continue
                            # Try to parse rect from PDF commands
                            try:
                                points = []
                                for i in range(0, 4):
                                    a = float(p[ti + i][0][0])
                                    b = float(p[ti + i][0][1])
                                    # log.debug('got a and b', a, b)
                                    points.append((a, b))
                                rect = QRectF(points[3][0], # left
                                              points[3][1], # bottom
                                              points[1][0] - points[3][0], # width
                                              points[1][1] - points[3][1]) # height
                                extracted_rects += [(color, rect)]
                                # delete the rect op's later
                                delete_indexes += [ti+3, ti+2, ti+1, ti]
                            except Exception as e:
                                log.debug(e)
                                continue

                    # ////////////////////////////
                    # /// End enumeration of p ///
                    # ////////////////////////////

                    extracted_rect_groups = []
                    for fr in extracted_rects:
                        if not self.group_highlights:
                            extracted_rect_groups += [[fr]]
                            continue
                        # Increase the size of each of them, then test
                        # which ones intersect. The ones that do should
                        # be grouped together.
                        def scale_rect(rect):
                            # assume the height is the stroke width.
                            # scale only scales the stroke width and
                            # adds that value as padding (otherwise the
                            # ends would come off).
                            new_rect = QRectF(rect)
                            pad = abs(rect.height() / 2)
                            new_rect.setLeft(rect.left() - pad)
                            new_rect.setTop(rect.top() - pad) # negated for coordinate system
                            new_rect.setRight(rect.right() + pad)
                            new_rect.setBottom(rect.bottom() + pad) # negated for coordinate system
                            return new_rect
                        # test this rect against all other known rect
                        # groups. if it doesn't fit, make a new one.
                        color = fr[0]
                        rect = fr[1]
                        orect_s = scale_rect(rect)
                        for erg_i, erg in enumerate(extracted_rect_groups):
                            if not rect:
                                break
                            for fr_i, fr in enumerate(erg):
                                if not rect:
                                    break
                                if color != fr[0]:
                                    continue
                                test_rect = fr[1]
                                trect_s = scale_rect(test_rect)
                                if orect_s.intersects(trect_s):
                                    extracted_rect_groups[erg_i] += [(color, rect)]
                                    rect = None
                        if rect:
                            extracted_rect_groups += [[(color, rect)]]

                    for gr in extracted_rect_groups:
                        group_quadpoints = []
                        group_rect = QRectF(0, 0, 0, 0)
                        for fr in gr:
                            color = fr[0]
                            rect = fr[1]
                            # QRect coordinate system is inverted (origin
                            # is top-left, not bottom-left like PDF), so
                            # needs to use inverted top/bottom.

                            # Keep track of group's total bounding box,
                            # needed as property of annot.
                            if rect.left() < group_rect.left():
                                group_rect.setLeft(rect.left())
                            if rect.right() > group_rect.right():
                                group_rect.setRight(rect.right())
                            if rect.top() < group_rect.top():
                                group_rect.setTop(rect.top())
                            if rect.bottom() > group_rect.bottom():
                                group_rect.setBottom(rect.bottom())

                            quadpoints = [rect.left(),  rect.bottom(), # LeftTop
                                          rect.right(), rect.bottom(), # RightTop
                                          rect.left(),  rect.top(),    # LeftBottom
                                          rect.right(), rect.top()]    # RightBottom
                            group_quadpoints += quadpoints

                        group_trect = [group_rect.left(), group_rect.top(),      # LeftBottom
                                       group_rect.right(), group_rect.bottom()]  # RightTop
                        if not '/Annots' in page:
                            page.Annots = pikepdf.Array()
                        a_dict = my_pdf.make_indirect(
                            pikepdf.Dictionary(
                                Type=pikepdf.Name('/Annot'),
                                Rect=group_trect,
                                T=self.author,
                                ANN='pdfmark',
                                Subtype=pikepdf.Name('/Highlight'),
                                P=page.obj,
                                CA=1.0,
                                C=color,
                                QuadPoints=group_quadpoints))
                        page.Annots.append(a_dict)
                    # /end for

                    # Delete marked indexes and unparse the stream
                    delete_indexes.sort(reverse=True)
                    for di in delete_indexes:
                        del p[di]
                    page.Contents[stream_index] = my_pdf.make_stream(
                        pikepdf.unparse_content_stream(p))
            except Exception as e:
                log.error('hit exception in webui mod renderer page')
                log.error(e)
        my_pdf.save()
        my_pdf.close()
        return True
