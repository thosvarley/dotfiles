'''
rcu.py
This is the primary model for the Remarkable Connection Utility.

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-26  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

from .config import Config
import log
import urllib.request

from PySide2.QtCore import QThreadPool, QSettings, QTimer
from PySide2.QtGui import QImage
from worker import Worker
import select
import base64
from .template import Template
from .display import DisplayRMGeneric
from .battery import BatteryRMGeneric

# For loading notebooks
import tarfile
import io
import json
import datetime
from .document import Document
from .collection import Collection

# For recovery mode
import subprocess
import platform
from pathlib import Path
import sys

class RCU:
    default_name = 'reMarkable'
    config_path = '$HOME/.config/remarkable'
    xochitlconf_path = config_path + '/xochitl.conf'
    cslconf_path = config_path + '/csl.conf'

    device_rcu_share_path = '$HOME/.local/share/davisr/rcu'

    @classmethod
    def convert_modelnum_to_hwtype(cls, modelnum):
        if 'RM100' == modelnum or 'RM102' == modelnum:
            return 'RM1'
        elif 'RM110' == modelnum:
            return 'RM2'
        elif 'RM02A' == modelnum:
            return 'RMPP'
        elif 'RM03A' == modelnum:
            return 'RMPPM'
        return None

    def __init__(self, QCoreApplication):
        self.config = Config()
        self.settings = QSettings()
        self.threadpool = QThreadPool()

        # fw3.14 introduced csl.conf used for various hardware
        # parameters. RM2 just has 'wifi', but RMPP has that plus
        # display settings.
        self.uses_csl = False

        self.is_in_recovery = False
        self.has_webui = None

        self.boot_disk = '/dev/mmcblk1'

        self.device_info = dict.fromkeys(
            ['model', 'serial', 'osver', 'cpu', 'ram', 'storage_used',
             'storage_max', 'kernel', 'kernel_bootargs', 'rcuname',
             'partition_table', 'cloud_user'])

        self.device_info['rcuname'] = self.default_name

        # These are new -- going to load them in the model and then exec
        # some callback in the pane to load async.
        self.templates_pane = None
        self.templates = set()

        self.notebooks_pane = None
        self.last_notebooks_checksum = None
        self.collections = set()
        self.documents = set()
        self.deleted_items = set()


    ################
    ## CONNECTION ##
    ####################################################################
    def is_connected(self):
        return self.config.is_connected()

    def is_using_usb(self):
        host = self.config.host.split(':')[0]
        if '10.11.99.1' != host:
            return False
        return True

    def connect(self):
        # Connect with the config
        ret = self.config.connect()
        if ret:
            self.load_device_info()
            self.is_in_recovery = False
        return ret

    def connect_restore(self, load_info=True):
        # Connect to a restore OS
        ret = self.config.connect_restore()
        # Test that it is actually the recovery OS!
        if ret:
            cmd = 'uname -a'
            out, err = self.run_cmd(cmd)
            actually_in_ros = False
            if 'rcu-rescue-os' in out.lower():
                actually_in_ros = True
            if actually_in_ros:
                log.info('!! in recovery mode !!')
                self.is_in_recovery = True
                if load_info:
                    log.info('@@@ load info was true!')
                    self.load_device_info()
            else:
                self.is_in_recovery = False
        return self.is_in_recovery

    def reconnect(self):
        if self.is_connected():
            self.config.disconnect()
        return self.connect()

    def reconnect_restore(self, load_info=True):
        if not self.is_connected():
            self.config.disconnect()
        return self.connect_restore(load_info=load_info)

    def run_cmd(self, cmd, raw=False, raw_noread=False,
                with_stdin=False, timeout=10):
        # Runs a command on the device
        if self.is_connected():
            try:
                # log.debug('running command: {}'.format(cmd))
                stdin, out, err = self.config.connection.exec_command(
                    cmd, timeout=timeout)
            except Exception as e:
                # Probably a timeout opening the channel
                self.config.disconnect(force=True)
                return ([], str(e))
            if not raw and not raw_noread:
                return (out.read().decode('utf-8'),
                        err.read().decode('utf-8'))
            if raw:
                return (out.read(), err.read())
            if raw_noread:
                if with_stdin:
                    return (out, err, stdin)
                return (out, err)
        else:
            # Session not active...what do?
            if self.reconnect():
                return self.run_cmd(cmd, raw)
            return ([], 'session is no longer active')

    def put_file(self, localfilepath, remotefilepath):
        # Puts a file to the device
        try:
            sftp = self.config.connection.open_sftp()
            sftp.put(localfilepath, remotefilepath)
        except Exception as e:
            log.error('sftp put error; ' + e.__str__())

    def get_file(self, remotefilepath, localfilepath, callback):
        # Gets a file from the device
        try:
            sftp = self.config.connection.open_sftp()
            sftp.get(remotefilepath, localfilepath, callback)
        except Exception as e:
            log.error('sftp get error; ' + e.__str__())

    def restart_xochitl(self):
        if self.display:
            # Reset display parameters for RM2
            self.display.invalidate_pixel_cache(clear_addr=True)
        cmd = 'systemctl reset-failed xochitl && systemctl restart xochitl'
        self.run_cmd(cmd)

    def stop_xochitl(self):
        if self.display:
            # Reset display parameters for RM2
            self.display.invalidate_pixel_cache(clear_addr=True)
        cmd = 'systemctl reset-failed xochitl && systemctl stop xochitl'
        self.run_cmd(cmd)

    def start_xochitl(self):
        cmd = 'systemctl reset-failed xochitl && systemctl start xochitl'
        self.run_cmd(cmd)

    def remount_home_as_readonly(self):
        # Skip for RMPP because cryptsetup makes remounting as readonly
        # troublesome. (/etc/dropear and /var/log/journal also attached
        # to same crypt disk).
        if self.get_hwtype() in ['RMPP', 'RMPPM']:
            log.info('skipping remount /home for RMPP')
            return True
        cmd = 'systemctl stop crashuploader && systemctl stop wpa_supplicant && cd / && mount -o remount,ro /home'
        out, err = self.run_cmd(cmd)
        if err and len(err):
            # Some kind of problem -- was it actually mounted ro? If
            # not, just abort.
            log.error('problem in remount_home_as_readonly')
            log.error(str(err))
            return False
        log.info('remounted home as readonly')
        return True

    def remount_home_reset(self):
        if self.get_hwtype() in ['RMPP', 'RMPPM']:
            log.info('skipping remount /home for RMPP')
            return True
        cmd = 'mount -o remount /home && systemctl start wpa_supplicant && systemctl start crashuploader'
        out, err = self.run_cmd(cmd)
        if err and len(err):
            log.error('problem in remount_home_reset')
            log.error(str(err))
            return False
        log.info('remounted home as normal')
        return True

    def restart_hw(self):
        if self.display:
            # Reset display parameters for RM2
            self.display.invalidate_pixel_cache(clear_addr=True)
        log.info('restarting hardware')
        self.run_cmd('/sbin/reboot')
        self.reconnect()


    def _retry_load_ros(self, cb):
        def retry(i):
            completed = False
            if i > 0:
                i -= 1
                completed = self._upload_recovery_os_for_real()
                if completed:
                    cb(completed)
                    return
                log.info('could not load the recovery os. {} retries left'.format(
                    i))
                QTimer.singleShot(2000, lambda: retry(i))
            else:
                cb(completed)
        retry(5)

    def _retry_connect_ros(self, cb, load_info=True):
        def retry(i):
            completed = False
            if i > 0:
                i -= 1
                log.info('reconnecting to restore os...')
                completed = self.reconnect_restore(load_info=load_info)
                if completed:
                    cb(completed)
                    return
                log.info('could not connect to the recovery os. {} retries left'.format(
                    i))
                QTimer.singleShot(5000, lambda: retry(i))
            else:
                cb(completed)
        retry(12)

    def upload_recovery_os(self, endcb, load_info=True):
        def loadretrydone(completed):
            if completed:
                # success, try to connect
                self._retry_connect_ros(endcb, load_info=load_info)
            else:
                # fail, done
                log.error('could not load recovery os. aborting')
                endcb(completed)
        self._retry_load_ros(loadretrydone)

    def _upload_recovery_os_for_real(self):
        selfdir = Path(__file__).parent
        if hasattr(sys, '_MEIPASS'):
            recoverydir = Path(selfdir.parent / 'recovery_os_build')
        else:
            recoverydir = Path(selfdir.parent.parent / 'recovery_os_build')
        cmd = {
            'FreeBSD': 'cd "{}" && ./imx_usb.fbsd12'.format(recoverydir),
            'Linux': 'cd "{}" && ./imx_usb.linux'.format(recoverydir),
            'Darwin': 'cd "{}" && ./imx_usb.mac'.format(recoverydir),
            'Windows': 'cd /d "{}" && .\imx_usb.win10'.format(recoverydir)
        }
        plat = platform.system()
        # The imx_usb utility does not use an error return code. I
        # should probably fix this there, but for now just look at the
        # result of the command for the 'error string'. TODO...
        done = subprocess.run(cmd[plat],
                              shell=True,
                              encoding='utf-8',
                              stderr=subprocess.PIPE)
        if 'no matching USB device found' in done.stderr:
            return False
        return True

    def make_free_space(self):
        out, err = self.run_cmd('journalctl --vacuum-size=10M')

    def test_uses_remount_fs(self):
        # tests to see if the following two functions, remount_fs_writable
        # and remount_fs_default, apply.
        return self.get_hwtype() in ['RMPP', 'RMPPM']

    def remount_fs_writable(self):
        # With the introduction of RMPP, the default root filesystem is
        # read-only.
        if self.test_uses_remount_fs():
            log.info('remounting fs as read-write')
            out, err = self.run_cmd('mount -o remount,rw /')
            # log.debug(out, err)

    def remount_fs_default(self):
        # With the introduction of RMPP, the default root filesystem is
        # read-only.
        if self.test_uses_remount_fs():
            log.info('remounting fs as read-only')
            out, err = self.run_cmd('mount -o remount,ro /')
            # log.debug(out, err)


    ######################
    ##  CONFIG EDITING  ##
    ####################################################################
    def get_config_prop(self, key, case_sensitive=True,
                        config='xochitl.conf'):
        confpath = '{}/{}'.format(self.config_path, config)
        csflag = ''
        if not case_sensitive:
            csflag = '-i'
        cmd = 'cat "{}" | grep {} "^{}=" | sort -r | tail -n 1 | cut -d= -f2'.format(
            confpath, csflag, key)
        out, err = self.run_cmd(cmd)
        if len(err.strip()):
            log.error(err)
            return
        val = out.strip()
        if val in ['true', 'on']:
            return True
        elif val in ['false', 'off']:
            return False
        return val

    def set_config_prop(self, key, val, config='xochitl.conf',
                        restart=True):
        # Qt interpolation
        # default for xochitl.conf
        trueval = 'true'
        falseval = 'false'
        if 'csl.conf' == config:
            trueval = 'on'
            falseval = 'off'
        if True is val:
            val = trueval
        elif False is val:
            val = falseval
        confpath = '{}/{}'.format(self.config_path, config)
        replacement = '{}={}'.format(key, val)

        # Does the key exist in the conf? If not, create it.
        key_test_cmd = 'grep -q "^{}=" "{}"; echo $?'.format(
            key, confpath)
        out, err = self.run_cmd(key_test_cmd)
        if '0' != out.strip():
            # # error, create key
            # log.info('creating new key {} in {}'.format(key, config))
            # create_key_cmd = 'echo "{}" >> "{}"'.format(replacement,
            #                                             confpath)
            # self.run_cmd(create_key_cmd)
            # ^^^ stubbed out for commit
            pass
        else:
            edit_cmd = 'sed -i "s/^{}=.*$/{}/g" "{}"'.format(
                key, replacement, confpath)
            self.run_cmd(edit_cmd)
        if restart:
            self.restart_xochitl()

    def is_webui_enabled(self):
        self.has_webui = self.get_config_prop('WebInterfaceEnabled')
        return self.has_webui

    def toggle_webui(self):
        curval = self.is_webui_enabled()
        return self.set_config_prop('WebInterfaceEnabled', not curval)

    def is_wifi_enabled(self):
        if self.uses_csl:
            val = self.get_config_prop('wifi', config='csl.conf')
        else:
            val = self.get_config_prop('wifion')
        return val

    def toggle_wifi(self):
        # Note: It might be preferable to set both csl.conf and
        # xochitl.conf's vars to the same semantic value. On the RMPP,
        # xochitl.conf doesn't have 'wifion'--does that mean that only
        curval = self.is_wifi_enabled()
        if self.uses_csl:
            self.set_config_prop('wifi', not curval, 'csl.conf')
        else:
            self.set_config_prop('wifion', not curval)

    def get_systemd_service(self, name):
        # Returns whether service is enabled or not.
        cmd = '/bin/systemctl is-enabled {}'.format(name)
        out, err = self.run_cmd(cmd)
        if len(err.strip()):
            log.error(err)
            return
        return out.strip() == 'enabled'

    def get_systemd_service_active(self, name):
        # Returns whether service is active or not.
        cmd = '/bin/systemctl is-active {}'.format(name)
        out, err = self.run_cmd(cmd)
        if len(err.strip()):
            log.error(err)
            return
        return out.strip() == 'active'

    def set_systemd_service(self, name, enable=True):
        c = 'enable' if enable else 'disable'
        log.info('set_systemd_service', name, enable)
        cmd = '/bin/systemctl {} {}'.format(c, name)
        out, err = self.run_cmd(cmd)

    def is_gt_eq_xochitl_version(self, string_to_test):
        # Use this function whenever testing for versions (or inferring
        # capabilities).
        v_now = list(map(int, self.device_info['osver'].split('.')))
        v_test = list(map(int, string_to_test.split('.')))
        ret = True
        for i, tv in enumerate(v_test):
            nv = v_now[i]
            if not tv <= nv:
                ret = False
        return ret

    def is_lt_xochitl_version(self, string_to_test):
        # Use this function whenever testing for versions (or inferring
        # capabilities).
        v_now = list(map(int, self.device_info['osver'].split('.')))
        v_test = list(map(int, string_to_test.split('.')))
        ret = True
        for i, tv in enumerate(v_test):
            nv = v_now[i]
            if not tv > nv:
                ret = False
        return ret


    ###################
    ##  DEVICE INFO  ##
    ####################################################################
    def get_hwtype(self):
        modelnum = self.device_info['model']
        return self.convert_modelnum_to_hwtype(modelnum)
    def register_device_info_pane(self, do_pane):
        self.device_info_pane = do_pane
        log.info('device_info registered')
    def load_device_info(self):
        # Loads device information. This is done here, rather than in
        # the Device Info pane, because this is very useful for other
        # panes to use in decisions.

        # Find the eMMC boot disk.
        out, err = self.run_cmd('''cat /etc/fstab \
                                       | grep -v '^#' | grep '/data' \
                                       | head -n 1 | awk '{print $1}' \
                                       | cut -d'p' -f1''')
        if 0 == len(out.strip()):
            out, err = self.run_cmd('''cat /etc/fstab \
                                           | grep -v '^#' | grep '/var/lib/uboot' \
                                           | head -n 1 | awk '{print $1}' \
                                           | cut -d'p' -f1''')
        if len(err):
            log.error('could not find boot disk--using default')
        elif len(out) > 2:
            self.boot_disk = out.strip()

        #########################################################
        # This is commented out because RMPP uses mmcblk0
        # # Guard against microSD mod, which mounts as mmcblk0
        # if '/dev/mmcblk0' == self.boot_disk:
        #     self.boot_disk = '/dev/mmcblk1'
        #########################################################

        log.info('boot disk is {}'.format(self.boot_disk))

        # Check for csl.conf (fw3.14)
        cmd = 'test -e "' + self.cslconf_path + '"; echo $?'
        out, err = self.run_cmd(cmd)
        if '0' == out.strip():
            self.uses_csl = True

        # Load initial web ui state (sets self.has_webui)
        self.is_webui_enabled()

        # Get serial and model numbers. TODO: there might be a better
        # way of doing this through `csl` on fw3.16(rmpp)+ or fw3.17...
        fw315_acpath = '$HOME/.local/share/remarkable/user-auth/auth-config.json'
        cmd = '''if [[ -e "''' + fw315_acpath + '''"  ]]; then \
                     awk -F'"device-id":"' '{print $2}' "''' + fw315_acpath + '''" \
                         | awk -F'"' '{print $1}'; \
                 else \
                     dd if=''' + self.boot_disk + '''boot1 bs=1 skip=4 count=15; \
                 fi'''
        # log.debug('fw315_acpath cmd', cmd)
        out, err = self.run_cmd(cmd)
        out = out.strip()
        if len(out) != 15:
            log.error('Unable to get serial number. ' + err)
            self.device_info['serial'] = None
            self.device_info['model'] = None
        else:
            self.device_info['serial'] = out
            self.device_info['model'] = out[0:5]

        out, err = self.run_cmd(
            '''cat /usr/share/remarkable/update.conf \
               | grep REMARKABLE_RELEASE_VERSION \
               | head -n 1 | cut -d'=' -f2''')
        out = out.strip('\n')
        if len(out) >= 3 and len(out) <= 11:
            self.device_info['osver'] = out
        else:
            log.info('os version not found--trying /etc/os-release')

            # RMPP
            out, err = self.run_cmd('(source /etc/os-release && echo $IMG_VERSION)')
            out = out.strip('\n')
            if len(out) >= 3 and len(out) <= 50:
                self.device_info['osver'] = out
            else:
                log.info('no IMG_VERSION in /etc/os-release, falling back')

                out, err = self.run_cmd('(source /etc/os-release && echo $NAME)')
                out = out.strip('\n')
                if len(out) >= 3 and len(out) <= 50:
                    self.device_info['osver'] = out
                else:
                    log.error('Unable to get OS version. ' + err)
                    self.device_info['osver'] = None

        # Once we know the model and osver, we can set the
        # device-specific attributes.
        self.display = DisplayRMGeneric.from_model(self)
        self.battery = BatteryRMGeneric.from_model(self)

        # Continue...
        out, err = self.run_cmd('''cat /proc/cpuinfo \
                                   | grep Hardware \
                                   | cut -d' ' -f2- \
                                   | sed 's/ (Device Tree)//g' ''')
        out = out.strip('\n')
        if len(out) < 5 or len(out) > 100:
            # RMPP cheat
            hwtype = self.get_hwtype()
            if 'RMPP' == hwtype:
                self.device_info['cpu'] = 'NXP i.MX 8M Mini'
            elif 'RMPPM' == hwtype:
                self.device_info['cpu'] = 'NXP i.MX 93'
            else:
                log.error('Unable to get CPU type. ' + err)
                self.device_info['cpu'] = None
        else:
            self.device_info['cpu'] = out

        out, err = self.run_cmd('''free \
                                   | grep Mem \
                                   | awk '{print $2}' ''')
        out = out.strip('\n')
        if len(out) < 4 or len(out) > 8:
            log.error('Unable to get RAM. ' + err)
            self.device_info['ram'] = None
        else:
            self.device_info['ram'] = int(int(out) / 1000)

        self.load_device_storage()

        out, err = self.run_cmd('uname -a')
        out = out.strip('\n')
        if len(out) < 15 or len(out) > 150:
            log.error('Unable to get kernel id. ' + err)
            self.device_info['kernel'] = None
        else:
            self.device_info['kernel'] = out

        out, err = self.run_cmd(
            'dmesg | grep "Kernel command line" | cut -d: -f2 \
            | tail -c +2')
        out = out.strip('\n')
        if len(out) < 15 or len(out) > 300:
            # RMPP cheat
            if 'RMPP' == self.get_hwtype():
                # TODO
                log.info('Unable to get kernel bootargs. ' + err)
                self.device_info['kernel_bootargs'] = None
            else:
                log.error('Unable to get kernel bootargs. ' + err)
                self.device_info['kernel_bootargs'] = None
        else:
            self.device_info['kernel_bootargs'] = out

        out, err = self.run_cmd('/sbin/fdisk -l')
        if len(out) < 500 or len(out) > 5000:
            log.error('Unable to get partition table. ' + err)
            self.device_info['partition_table'] = None
        else:
            self.device_info['partition_table'] = base64.b64encode(
                bytes(out, 'utf-8')).decode('utf-8')

        # Check if this is a reMarkable Cloud user.
        #
        # Early firmware had 'usertoken', later firmware (fw3?) uses
        # 'UserToken'.
        #
        # If a user has upgraded their tablet from the old firmware to
        # new, it might contain a 'usertoken' with an old/unused token,
        # and a 'UserToken' with nothing (if they have since
        # disconnected).
        #
        # get_config_prop() will sort and return only the last instance,
        # so setting case_sensitive=False will order:
        #   usertoken=@ByteArray(xxxx)
        #   UserToken=
        # and take only the last one. Since reMarkable's updated key
        # is capitalized, it will be last in the sort.
        usertoken = self.get_config_prop('usertoken',
                                         case_sensitive=False)
        if '' == usertoken or '@Invalid()' == usertoken:
            usertoken = None
        if usertoken:
            self.device_info['cloud_user'] = True
            log.info('is a cloud user')
        else:
            self.device_info['cloud_user'] = False
            log.info('is not a cloud user')

        self.load_device_name()

        if hasattr(self, 'device_info_pane'):
            self.device_info_pane.update_view(loadinfo=False)

    def load_device_storage(self):
        # These two are hard-set
        self.device_info['storage_max'] = 0
        self.device_info['storage_used'] = 0

        # New method....
        out, err = self.run_cmd('''df /home''')
        if len(err.strip()):
            log.error('error running df')
            log.error(err)
            return
        out = out.strip().splitlines()

        # 'out' should be two lines. First line: header. Last line:
        # /home partition data. RM1 only has two lines, RM2enc and RMPP
        # have three lines (middle /dev/mapper/... line ignored).
        header = out[0].split()
        data = out[len(out)-1].split()
        i_offset = len(out) - 2
        i_blocks = header.index('1K-blocks') - i_offset
        i_used = header.index('Used') - i_offset
        # If any of the above weren't found, abort.
        if i_blocks < 0 or i_used < 0:
            log.error('error parsing output of df')
            return

        num_bytes_tot = int(data[i_blocks]) * 1024
        num_bytes_used = int(data[i_used]) * 1024
        self.device_info['storage_max'] = num_bytes_tot
        self.device_info['storage_used'] = num_bytes_used

        if hasattr(self, 'device_info_pane'):
            self.device_info_pane.update_view(loadinfo=False)

    def load_device_name(self):
        # Just loads the device name (broken out because its quicker)
        namefile = '$HOME/.rcu-name'

        cmd = 'cat "{}"'.format(namefile)
        out, err = self.run_cmd(cmd)
        if len(err):
            log.info('device does not have a name ({})'.format(
                err.strip()))
            self.device_info['rcuname'] = type(self).default_name
            return
        realname = out.strip('\n').strip()
        self.device_info['rcuname'] = realname

    def set_device_name(self, name):
        namefile = '$HOME/.rcu-name'

        if not name or name == '':
            self.device_info['rcuname'] = type(self).default_name
            cmd = 'rm -f "{}"'.format(namefile)
            self.run_cmd(cmd)
        else:
            cmd = 'echo "{}" > "{}"'.format(name, namefile)
            out, err, sin = self.run_cmd(cmd, raw_noread=True,
                                               with_stdin=True)
            sin.write(name.encode('utf-8'))
            sin.close()
            self.device_info['rcuname'] = name
            log.info('set device name to {}'.format(name))


    #################
    ##  TEMPLATES  ##
    ####################################################################
    def register_templates_pane(self, templates_pane):
        self.templates_pane = templates_pane

    def load_templates(self, trigger_ui=True):
        # Loads the templates, but not fully; just enough to emit an
        # item back for the GUI. Templates can be loaded
        # fully within themselves (which saves GUI thread time)
        log.info('loading templates')

        # Find safe templates, disable the rest. Safe ones (as is
        # currently supported) must exist as either .svg or .png.
        searchpath = Template.syspathpfx
        cmd = 'cd "{}" && ls *.svg *.png | sed "s/\.svg//g" | sed "s/\.png//g"'.format(searchpath)
        out, err = self.run_cmd(cmd)
        passing_templates = set(out.strip().splitlines())

        # When re-loading templates, sometimes they get deleted. So,
        # we need to keep a list of the ones that no longer exist,
        # so they can be removed from the primary list.
        new_templates = set()

        templates_obj = Template(self).get_device_templates_dict()
        for t in templates_obj['templates']:
            # If this already exists in the old set, use that. Using
            # get_template().from_dict() will keep the old template
            # object, but update it with new information and clear
            # the SVG.
            template = self.get_template(t['filename']).from_dict(t)
            if t['filename'] not in passing_templates:
                template.disabled = True
            new_templates.add(template)
        self.templates = new_templates

        if self.templates_pane and trigger_ui:
            self.templates_pane.load_items()

        # templates_obj = Template(self).get_device_templates_dict()
        # for t in templates_obj['templates']:
        #     template = Template(self).from_dict(t)
        #     self.add_template(template)

    def template_is_loaded(self, tfilename):
        for template in self.templates:
            if template.filename == tfilename:
                return True
        return False

    def get_template(self, tfilename):
        # Search for a template that already exists, or return a new one
        # if it doesn't.
        for template in self.templates:
            if template.filename == tfilename:
                # already exists
                # reset svg so it reloads on a new click
                template.svg = None
                return template
        return Template(self)

    def add_template(self, atemplate):
        # Only add if not already exists (because this function can
        # be used for a refresh).
        usetemplate = self.get_template(atemplate.filename)
        # clone
        usetemplate.from_dict(atemplate.to_dict(with_filename=True))
        usetemplate.svg = atemplate.svg
        self.templates.add(usetemplate)
        if self.templates_pane:
            self.templates_pane.load_items()
        return usetemplate

    def add_new_template_from_dict(self, adict):
        template = Template(self).from_dict(adict)
        return self.add_template(template)

    def add_new_template_from_archive(self, rmtfile):
        template = Template(self).from_archive(rmtfile)
        return self.add_template(template)


    #################
    ##  NOTEBOOKS  ##
    ####################################################################
    def register_notebooks_pane(self, nb_pane):
        self.notebooks_pane = nb_pane

    def load_notebooks(self, trigger_ui=True, force=False):
        # Determine if there are changed notebooks to load based on the
        # checksum of the directory listing (fast method to prevent
        # excessive data transmission).
        cmd = '''cd $HOME/.local/share/remarkable/xochitl && ls -lha *.content *.metadata | md5sum | cut -d' ' -f1'''
        out, err = self.run_cmd(cmd)
        if len(err):
            log.error('problem getting documents list')
            log.error(err)
            log.error('aborting notebook load')
            # return False
        new_checksum = out.strip()
        if self.last_notebooks_checksum == new_checksum and not force:
            #log.info('notebooks are already up-to-date')
            return False
        self.last_notebooks_checksum = new_checksum
        log.info('loading notebooks')

        ## Todo: relocate this into the Notebook() class, like it is
        ## for the templates.
        # Read the notebook metadata
        cmd = '''find $HOME/.local/share/remarkable/xochitl \
                      -maxdepth 1 \
                      -name "*.content" -o -name "*.metadata" \
                      | sed "s!.*/!!" \
                      | tar -T /dev/stdin -cf - \
                      -C $HOME/.local/share/remarkable/xochitl'''
        out, err = self.run_cmd(cmd, raw=True)
        if len(err.decode('utf-8')):
            log.error('problem getting metadata/content archive')
            log.error(err)
            return False

        mdarchive = tarfile.open(fileobj=io.BytesIO(out))
        gathered_ids = set()
        for ti in mdarchive.getmembers():
            gathered_ids.add(ti.name.split('.')[0])

        # Make a set of the new items. If the collections or notebooks
        # already exist, use those, but reload them with new metadata.
        # Otherwise, make new ones. Add them to these sets, then
        # replace the master sets with these new ones.
        new_collections = set()
        new_documents = set()
        new_deleted_items = set()

        i = 0
        for uuid in gathered_ids:
            # Change with fw3.15: when creating a collection on the
            # tablet, a .content file used to be created (although only
            # with `{}`). With 3.15, no .content file is created.
            try:
                metadatafile = mdarchive.extractfile(uuid + '.metadata')
                metadata = json.load(metadatafile)
            except Exception as e:
                log.error('unable to parse metadata', uuid)
                log.error(e)
                # metadata required, so continue
                continue
            try:
                contentfile = mdarchive.extractfile(uuid + '.content')
                content = json.load(contentfile)
            except Exception as e:
                # log.error('unable to parse content', uuid)
                # log.error(e)
                # content not required
                content = {}

            if 'fileType' not in content:
                filetype = None
            elif '' == content['fileType']:
                filetype = 'notebook'
            else:
                filetype = content['fileType']

            metadata['id'] = uuid
            metadata['filetype'] = filetype

            item = None
            if 'CollectionType' == metadata['type']:
                collection = self.get_collection(metadata['id']).from_dict(metadata)
                collection._content_dict = content
                if not collection.deleted:
                    new_collections.add(collection)
                else:
                    new_deleted_items.add(collection)
            elif 'DocumentType' == metadata['type']:
                document = self.get_document(metadata['id']).from_dict(metadata)
                if not document.deleted:
                    new_documents.add(document)
                else:
                    new_deleted_items.add(document)
        mdarchive.close()

        self.collections = new_collections
        self.documents = new_documents
        self.deleted_items = new_deleted_items

        if self.notebooks_pane and trigger_ui:
            self.notebooks_pane.load_items()

        # Reload the device info too--storage probably changed.
        self.load_device_storage()

        return True

    def document_exists(self, did):
        for document in self.documents:
            if document.uuid == did:
                return True
        return False

    def collection_exists(self, cid):
        for collection in self.collections:
            if collection.uuid == cid:
                return True
        return False

    def get_collection(self, cid):
        # Returns the existing collection, or returns a new one if it
        # didn't exist.
        for collection in self.collections:
            if collection.uuid == cid:
                return collection
        collection = Collection(self)
        return collection

    def get_document(self, did):
        # Returns the existing document, or returns a new one if it
        # didn't exist.
        for document in self.documents:
            if document.uuid == did:
                return document
        return Document(self)
