'''
text_handler.py
This file handles plain text and Markdown data conversion.

RCU is a management client for the reMarkable Tablet.
Copyright (C) 2020-26  Davis Remmel

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
'''

import log
from .rmscene.text import TextDocument
from .rmscene import read_tree
from .rmscene import scene_items as si

def read_text_v6(source):
    source.seek(0)
    tree = read_tree(source)
    testdoc = TextDocument.from_scene_item(tree.root_text)

    out_text = ''
    number1_cnt = 1  # first level (no) indent
    number2_cnt = 1  # second level indent
    for line in testdoc.contents:
        # annotated_
        stl = None
        try:
            stl = line.style.value
        except:
            pass

        stl_line = ''
        for group in line.contents:
            s = group.s
            p = group.properties
            if 'font-weight' in p:
                if 'bold' == p['font-weight']:
                    s = '**{}**'.format(s)
            if 'font-style' in p:
                if 'italic' == p['font-style']:
                    s = '*{}*'.format(s)
            stl_line += s

        def give_space(out_text):
            if '' != out_text \
               and '\n\n' != out_text[-2:]:
                out_text += '\n'
            return out_text

        if stl != si.ParagraphStyle.NUMBER:
            if stl != si.ParagraphStyle.NUMBER2:
                number1_cnt = 1  # reset

        if stl != si.ParagraphStyle.NUMBER2:
            number2_cnt = 1  # reset

        if stl == si.ParagraphStyle.HEADING:
            out_text = give_space(out_text)
            out_text += '# {}\n\n'.format(stl_line)
        elif stl == si.ParagraphStyle.HEADING2:
            out_text = give_space(out_text)
            out_text += '## {}\n\n'.format(stl_line)
        # Asterisk bullets
        elif stl == si.ParagraphStyle.BULLET:
            out_text += '* {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.BULLET2:
            out_text += '  * {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.CHECKBOX:
            out_text += '* [ ] {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.CHECKBOX_CHECKED:
            out_text += '* [X] {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.CHECKBOX2:
            out_text += '  * [ ] {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.CHECKBOX2_CHECKED:
            out_text += '  * [X] {}\n'.format(stl_line)
        # Hyphen bullets
        elif stl == si.ParagraphStyle.BULLET:
            out_text += '- {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.BULLET2:
            out_text += '  - {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.CHECKBOX:
            out_text += '- [ ] {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.CHECKBOX_CHECKED:
            out_text += '- [X] {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.CHECKBOX2:
            out_text += '  - [ ] {}\n'.format(stl_line)
        elif stl == si.ParagraphStyle.CHECKBOX2_CHECKED:
            out_text += '  - [X] {}\n'.format(stl_line)
        # Numbers
        elif stl == si.ParagraphStyle.NUMBER:
            out_text += '{}. {}\n'.format(number1_cnt, stl_line)
            number1_cnt += 1
        elif stl == si.ParagraphStyle.NUMBER2:
            out_text += '  {}. {}\n'.format(number2_cnt, stl_line)
            number2_cnt += 1
        # Plain
        else:
            out_text = give_space(out_text)
            if '' != stl_line:
                out_text += '{}\n'.format(stl_line)
            out_text = give_space(out_text)
    return out_text


from uuid import uuid4
from .rmscene.scene_stream import RootTextBlock, SceneGroupItemBlock, TreeNodeBlock, PageInfoBlock, AuthorIdsBlock, MigrationInfoBlock, SceneTreeBlock, SceneInfo
from .rmscene.crdt_sequence import CrdtSequence, CrdtSequenceItem
from .rmscene.scene_items import Text, ParagraphStyle, Group
from .rmscene.tagged_block_common import CrdtId, LwwValue
from .rmscene import read_blocks
import re
from pathlib import Path

class BlockManager:
    @classmethod
    def split_style(cls, line):
        # Split a Markdown line according to each formatted element.
        new_text = line
        new_style = ParagraphStyle.PLAIN
        style_table = [
            ('^# ', ParagraphStyle.HEADING),
            ('^## ', ParagraphStyle.HEADING2),
            # Asterisk bullets
            ('^\* ', ParagraphStyle.BULLET),
            ('^  \* ', ParagraphStyle.BULLET2),
            ('^\* \[ \] ', ParagraphStyle.CHECKBOX),
            ('^\* \[X\] ', ParagraphStyle.CHECKBOX_CHECKED),
            ('^\* \[x\] ', ParagraphStyle.CHECKBOX_CHECKED),
            ('^  \* \[ \] ', ParagraphStyle.CHECKBOX2),
            ('^  \* \[X\] ', ParagraphStyle.CHECKBOX2_CHECKED),
            ('^  \* \[x\] ', ParagraphStyle.CHECKBOX2_CHECKED),
            # Hyphen bullets
            ('^\- ', ParagraphStyle.BULLET),
            ('^  \- ', ParagraphStyle.BULLET2),
            ('^\- \[ \] ', ParagraphStyle.CHECKBOX),
            ('^\- \[X\] ', ParagraphStyle.CHECKBOX_CHECKED),
            ('^\- \[x\] ', ParagraphStyle.CHECKBOX_CHECKED),
            ('^  \- \[ \] ', ParagraphStyle.CHECKBOX2),
            ('^  \- \[X\] ', ParagraphStyle.CHECKBOX2_CHECKED),
            ('^  \- \[x\] ', ParagraphStyle.CHECKBOX2_CHECKED),
            # Numbers
            ('^[0-9]+\. ', ParagraphStyle.NUMBER),
            ('^  [0-9]+\. ', ParagraphStyle.NUMBER2)
        ]
        for t in style_table:
            pat = re.compile(t[0])
            mat = pat.match(line)
            if mat and 0 == mat.start():
                # starts with
                new_text = re.sub(pat, '', line)
                new_style = t[1]
        return (new_style, new_text)

    @classmethod
    def split_formats(cls, line):
        # Split a line into individual reMarkable format elements.
        # Currently, these are 1:1 with Markdown format tags, but
        # that might not always be the case! (2026-01)
        # ***value***, **value**, or *value*
        pattern = '(\*\*\*.*?\*\*\*|\*\*.*?\*\*|\*.*?\*)'
        ret = re.split(pattern, line)
        # no empty ones
        for ri in ret:
            if '' == ri:
                ret.remove('')
        return ret

    def __init__(self):
        self.base_counter = 16
        self.blocks = [
            AuthorIdsBlock(
                author_uuids={1: uuid4()}),
            MigrationInfoBlock(
                extra_data=b'',
                migration_id=CrdtId(1, 1),
                is_device=True,
                _unknown=False),
            PageInfoBlock(
                loads_count=0,
                merges_count=0,
                text_chars_count=0,
                text_lines_count=0,
                type_folio_use_count=0),
            SceneInfo(
                current_layer=LwwValue(
                    timestamp=CrdtId(0, 0),
                    value=CrdtId(0, 0)),
                background_visible=LwwValue(
                    timestamp=CrdtId(0, 0),
                    value=True),
                root_document_visible=LwwValue(
                    timestamp=CrdtId(0, 0),
                    value=True),
                paper_size=(1620, 2160)),
            SceneTreeBlock(
                tree_id=CrdtId(0, 11),
                node_id=CrdtId(0, 0),
                is_update=True,
                parent_id=CrdtId(0, 1)),
            RootTextBlock(
                block_id=CrdtId(0, 0),
                value=Text(
                    items=CrdtSequence(),
                    styles={},
                    pos_x=-576.0,
                    pos_y=234.0,
                    width=1152.0)),
            TreeNodeBlock(
                group=Group(
                    node_id=CrdtId(0, 1),
                    children=CrdtSequence(),
                    label=LwwValue(timestamp=CrdtId(0, 0), value=''),
                    visible=LwwValue(
                        timestamp=CrdtId(0, 0),
                        value=True),
                    anchor_id=None,
                    anchor_type=None,
                    anchor_threshold=None,
                    anchor_origin_x=None)),
            TreeNodeBlock(
                extra_data=b'',
                group=Group(
                    node_id=CrdtId(0, 11),
                    children=CrdtSequence(),
                    label=LwwValue(timestamp=CrdtId(0, 12), value='Layer 1'),
                    visible=LwwValue(timestamp=CrdtId(0, 0), value=True),
                    anchor_id=None,
                    anchor_type=None,
                    anchor_threshold=None,
                    anchor_origin_x=None)),
            SceneGroupItemBlock(
                extra_data=b'',
                parent_id=CrdtId(0, 1),
                item=CrdtSequenceItem(
                    item_id=CrdtId(0, 13),
                    left_id=CrdtId(0, 0),
                    right_id=CrdtId(0, 0),
                    deleted_length=0,
                    value=CrdtId(0, 11)),
                extra_value_data=b'')]

    def add_segment(self, new_value, new_style=ParagraphStyle.PLAIN,
                    author=1):
        # log.debug('add_segment', new_value, new_style, author)

        # No empty string values!
        if type(new_value) is str and '' == new_value:
            log.error('add_segment: illegal no-char string value passed in!')
            return

        root = next(b for b in self.blocks if isinstance(b, RootTextBlock))
        page_info = next(b for b in self.blocks if isinstance(b, PageInfoBlock))
        items = list(root.value.items)

        # Does an item already exist? We need to reference it at our 'left'.
        last_item_id = items[-1] if items else None

        # loop through all the items of this author, find the latest one
        for item in root.value.items._items:
            # log.debug('ITEM IS', item)
            if author == item.part1:
                if self.base_counter < item.part2:
                    self.base_counter = item.part2

        # Make IDs
        if last_item_id is None:
            # first item
            left_id = CrdtId(0, 0)
            right_id = CrdtId(0, 0)
            item_id = CrdtId(author, self.base_counter)
        else:
            last_item = root.value.items._items[last_item_id]
            right_id = CrdtId(0, 0)  # every new item is terminated like this

            # if this item has a text value, its left needs to be at the last text item.
            if type(new_value) is str:
                items = root.value.items.sequence_items()
                i = len(items) - 1
                while i >= 0:
                    it = items[i]
                    if type(it.value) is str:
                        # found it
                        break
                    i -= 1
                left_id = CrdtId(author, items[i].item_id.part2 + len(items[i].value)-1)
            else:
                left_id = CrdtId(author, self.base_counter - 1)


        # Only make a timestamp if we're adding a new text style.
        if type(new_value) is str:
            if left_id == CrdtId(0, 0) \
               or new_style is not ParagraphStyle.PLAIN:
                ts_id = CrdtId(author, self.base_counter)
                # self.base_counter += 1
                # ^^ commented out because it was interfering with
                #    styling. tough to keep track.

        item_id = CrdtId(author, self.base_counter)

        # Add to base_counter if string
        if type(new_value) is str:
            # A numerical list is passed a string, but has a length of
            # zero, which messes up the count. The 'or 1' is here to
            # keep an accurate count.
            self.base_counter += len(new_value)
        else:
            self.base_counter += 1

        # add to to RootTextBlock
        new_item = CrdtSequenceItem(
            item_id=item_id,
            left_id=left_id,
            right_id=right_id,
            deleted_length=0,
            value=new_value
        )
        root.value.items.add(new_item)

        if type(new_value) is str:
            # if the style is plain, don't add it unless 0,0
            if left_id == CrdtId(0, 0) or new_style is not ParagraphStyle.PLAIN:
                root.value.styles[left_id] = LwwValue(
                    timestamp=ts_id,
                    value=new_style
                )
            page_info.text_chars_count += len(new_value)
            if 0 == page_info.text_lines_count:
                page_info.text_lines_count += 1
            else:
                page_info.text_lines_count += new_value.count('\n')

        return new_item

def _debug_pretty_print_blocks(blocks):
        root = next(b for b in blocks if isinstance(b, RootTextBlock))
        for i in root.value.items.sequence_items():
            log.debug('   ', i)
        log.debug('           *** STYLES ***')
        for i in root.value.styles:
            log.debug('      ', i, root.value.styles[i])
        log.debug()
        log.debug()

def _TEST_print_blocks_for_file(filepath):
    # haack!!! print the crdtsequence for a test file
    with open(Path(filepath), 'rb') as nativerm:
        bl = list(read_blocks(nativerm))
        log.debug('****** PRINTING BLOCKS - {} ******'.format(filepath))
        _debug_pretty_print_blocks(bl)

def markdown_file_to_blocks(infile):
    bm = BlockManager()

    def insval_before(target_item, insval):
        b1 = bm.add_segment(insval)
        b1.left_id = CrdtId(
            target_item.item_id.part1,
            target_item.item_id.part2 - 1)
        b1.right_id = target_item.item_id
    def insval_after(target_item, insval):
        b2 = bm.add_segment(insval)
        b2.left_id = CrdtId(
            target_item.item_id.part1,
            target_item.item_id.part2 + len(target_item.value)-1)
        b2.right_id = CrdtId(
            target_item.item_id.part1,
            target_item.item_id.part2 + len(target_item.value))
        b2.right_id = CrdtId(0, 0)
    def bold_before(target_item):
        return insval_before(target_item, 1)
    def unbold_after(target_item):
        return insval_after(target_item, 2)
    def italic_before(target_item):
        return insval_before(target_item, 3)
    def unitalic_after(target_item):
        return insval_after(target_item, 4)

    ####################################################################
    ##  ACTUAL PROGRAM  ##
    ######################

    infile.seek(0)
    raw_text = infile.read()
    md_lines = raw_text.splitlines()

    for line_i, line in enumerate(md_lines):
        # Skip blank lines when they appear between plain types.
        #
        # TODO: these are ineffient to compute on every cycle, it's
        # doing 3x the computation it actually requires
        prev_line_style, prev_line_txt = (ParagraphStyle.PLAIN, '')
        if line_i > 0:
            prev_line_style, prev_line_txt = \
                bm.split_style(md_lines[line_i-1])
        next_line_style, next_line_txt = (ParagraphStyle.PLAIN, '')
        if line_i < len(md_lines) - 1:
            next_line_style, next_line_txt = \
                bm.split_style(md_lines[line_i+1])
        ord_types = [ParagraphStyle.PLAIN,
                     ParagraphStyle.HEADING,
                     ParagraphStyle.HEADING2]
        if '' == line:
            if prev_line_style in ord_types \
               or next_line_style in ord_types:
                continue

        # Always keep the line ending true (copying reMarkable's lead)
        line = line + '\n'
        style, unstyled_line = bm.split_style(line)

        # Reflow/un-wrap paragraph text. Originally this was to be
        # optional and in the ExportPrefsWidget, but I now think it's
        # better to do it by default because it's how the Markdown spec
        # is actually defined.
        if style == ParagraphStyle.PLAIN \
           and next_line_style == ParagraphStyle.PLAIN \
           and '' != next_line_txt:
            prev_line_style = style
            try:
                md_lines[line_i+1] = line.strip() + ' ' \
                    + md_lines[line_i+1]
                continue
            except:
                pass

        prev_line_style = style
        f_elements = bm.split_formats(unstyled_line)

        # If no f_elements are returned, there is no text data in this
        # line and it should be disregarded. As of fw3.24, that line
        # cannot be created on the tablet
        if not len(f_elements):
            continue

        # This section handles unclosed tags with the ele != x check. We
        # want to keep them, so they aren't handled in split_formats()
        # anymore. Output should always look like the input.
        for ele in f_elements:
            if ele.startswith('**') and ele.endswith('**') \
               and ele != '**':
                ele = ele.replace('**', '')
                # does it still have italic?
                if ele.startswith('*') and ele.endswith('*') \
                   and ele != '*':
                    ele = ele.replace('*', '')
                    seg = bm.add_segment(ele, style)
                    bold_before(seg)
                    unbold_after(seg)
                    italic_before(seg)
                    unitalic_after(seg)
                else:
                    seg = bm.add_segment(ele, style)
                    bold_before(seg)
                    unbold_after(seg)
            elif ele.startswith('*') and ele.endswith('*') \
                 and ele != '*' and ele != '**':
                ele = ele.replace('*', '')
                seg = bm.add_segment(ele, style)
                italic_before(seg)
                unitalic_after(seg)
            else:
                seg = bm.add_segment(ele, style)
            # Disregard style for rest of this line, it's no longer
            # significant.
            style = ParagraphStyle.PLAIN

    ##  DEBUG  ##
    # _debug_pretty_print_blocks(bm.blocks)

    # _TEST_print_blocks_for_file('/tmp/master.rm')
    # log.debug('****** PRINTING BLOCKS - {} ******'.format('generated'))
    # _debug_pretty_print_blocks(bm.blocks)

    return bm.blocks
